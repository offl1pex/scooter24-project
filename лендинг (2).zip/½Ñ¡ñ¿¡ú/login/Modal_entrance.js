function opena() {
    document.getElementById('reg-block').style.display = 'block';
    document.getElementById('bg_fon').style.display = 'block';
}
function сlose_modal_entrance() {
    document.getElementById('reg-block').style.display = 'none';
    document.getElementById('bg_fon').style.display = 'none';
}