var btn_sum = document.querySelector('.count-but_plus');
var btn_minus = document.querySelector('.count-but_minus');
var sum = 0;
var text = document.querySelector('.count-num').textContent;
btn_sum.addEventListener("click", function () {
    sum++
    document.querySelector('.count-num').innerHTML = sum;
})
btn_minus.addEventListener("click", function () {
    if (sum > 0) {
        sum--
        document.querySelector('.count-num').innerHTML = sum;
    } else {
        alert("Отрицательное значение не возможно")
    }
})
